Olivier MARCENAC 
olivier.marcenac@epfedu.fr 
26/03/2021

Les Difficultés rencontrées :
- Les beans
    Cette partie du cours était assez dur comparativement aux autres. Implémenter les beans a été très court mais plein d'incertitude.

- Les mocks et tests
    Les tests unitaire sur les classes de modele on été beaucoup plus simple à faire que les mocks des classes service. 
    Gérer les throws dans ces classes est un enfer je trouve.

- La contrainte sur les 30 jours de reservation sans pause pour une voiture
    J'ai eu du mal a pensée la fonction. Parcourir toute la liste du findbyvehicule_id() parraissait très inéficasse et brutal. 
    J'ai éssayer donc de trié la liste en fonction de la date de debut et de seulement parcourir les elements adjacent à la voiture 
    à tester. Je n'ai pas réussit a récuperer l'index de la voiture à tester après avoir trier la liste et je trouve ça dommage.
    J'ai eu beaucoup de mal avec l'implementation de Comparable et l'override de compareTo() afin de pouvoir trié des reservations


Commande pour lancer le site :
mvn tomcat7:run
