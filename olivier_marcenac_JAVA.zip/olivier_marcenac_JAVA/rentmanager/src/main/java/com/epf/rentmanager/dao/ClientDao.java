package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.persistence.ConnectionManager;

import org.springframework.stereotype.Repository;

@Repository
public class ClientDao {

	public ClientDao() {

	}

	private static final String CREATE_CLIENT_QUERY = "INSERT INTO Client(nom, prenom, email, naissance) VALUES(?, ?, ?, ?);";
	private static final String DELETE_CLIENT_QUERY = "DELETE FROM Client WHERE id=?;";
	private static final String FIND_CLIENT_QUERY = "SELECT nom, prenom, email, naissance FROM Client WHERE id=?;";
	private static final String FIND_CLIENTS_QUERY = "SELECT id, nom, prenom, email, naissance FROM Client;";
	private static final String UPDATE_CLIENT_QUERY = "UPDATE Client SET nom = ?, prenom = ?, email = ?, naissance = ? WHERE id= ?;";
	private static final String COUNT_CLIENTS_QUERY = "SELECT COUNT(id) AS count FROM Client;";
	private static final String FIND_EMAIL_QUERY = "SELECT id FROM Client WHERE email=?;";

	/**
	 * Crée le client.
	 * 
	 * @param client / Le client à créer.
	 * @return int / L'id du client créer.
	 * @throws DaoException
	 */
	public int create(Client client) throws DaoException {
		int id = 0;
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(CREATE_CLIENT_QUERY,
					id = Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, client.getNom());
			ps.setString(2, client.getPrenom());
			ps.setString(3, client.getEmail());
			ps.setDate(4, Date.valueOf(client.getNaissance()));

			ps.execute();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			throw new DaoException("Erreur lors de la création du client");
		}
		return id;
	}

	/**
	 * Update le client.
	 * 
	 * @param client / Une Client avec un id et tout les paramètres à changer ainsi
	 *               que ceux non modifié.
	 * @throws DaoException
	 */
	public void update(Client client) throws DaoException {
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(UPDATE_CLIENT_QUERY);
			ps.setString(1, client.getNom());
			ps.setString(2, client.getPrenom());
			ps.setString(3, client.getEmail());
			ps.setDate(4, Date.valueOf(client.getNaissance()));
			ps.setInt(5, client.getId());

			ps.execute();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			throw new DaoException("Erreur lors de l'update");
		}
	}

	/**
	 * Conte le nombre de clients dans la Database.
	 * 
	 * @return int /Le nombre de clients.
	 * @throws DaoException
	 */
	public int count() throws DaoException {
		int count = 0;
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(COUNT_CLIENTS_QUERY);
			ResultSet resultSet = ps.executeQuery();
			while (resultSet.next()) {
				count = resultSet.getInt("count");
			}
			ps.execute();
			resultSet.close();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			throw new DaoException("Erreur lors du count");
		}
		return count;
	}

	/**
	 * Delete le client.
	 * 
	 * @param id / L'id du client à delete.
	 * @throws DaoException
	 */
	public void delete(int id) throws DaoException {
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(DELETE_CLIENT_QUERY);
			ps.setInt(1, id);
			ps.execute();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			throw new DaoException("Erreur lors du delete");
		}
	}

	/**
	 * @param id /L'id du client à trouver
	 * @return Optional<Client> /Le client il a été trouvé/ Null sinon
	 * @throws DaoException
	 */
	public Optional<Client> findById(int id) throws DaoException {
		Client client = new Client();
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(FIND_CLIENT_QUERY);
			ps.setInt(1, id);
			ps.execute();
			ResultSet resultSet = ps.executeQuery();
			while (resultSet.next()) {
				client.setId(id);
				client.setNom(resultSet.getString("nom"));
				client.setPrenom(resultSet.getString("prenom"));
				client.setEmail(resultSet.getString("email"));
				client.setNaissance(resultSet.getDate("naissance").toLocalDate());
			}
			resultSet.close();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			throw new DaoException("Erreur lors du find by id=" + id);
		}
		return Optional.ofNullable(client);

	}

	/**
	 * @return List<Client> /Liste de tout les clients
	 * @throws DaoException
	 */
	public List<Client> findAll() throws DaoException {
		List<Client> result = new ArrayList<>();
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(FIND_CLIENTS_QUERY);

			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Client client = new Client();
				client.setId(resultSet.getInt("id"));
				client.setNom(resultSet.getString("nom"));
				client.setPrenom(resultSet.getString("prenom"));
				client.setNaissance(resultSet.getDate("naissance").toLocalDate());
				client.setEmail(resultSet.getString("email"));
				result.add(client);
			}
			resultSet.close();
			preparedStatement.close();
			connection.close();

		} catch (SQLException e) {
			throw new DaoException("Erreur lors du find all");
		}
		return result;
	}

	/**
	 * @param client Le client à teste
	 * @return boolean /True si l'email n'existe pas/ False sinon
	 * @throws DaoException
	 */
	public boolean hasNoSameEmail(Client client) throws DaoException {
		boolean hasNoSameEmail = true;
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(FIND_EMAIL_QUERY);
			ps.setString(1, client.getEmail());
			ps.execute();

			ResultSet resultSet = ps.executeQuery();
			while (resultSet.next()) {
				//if (resultSet.getInt("id") != client.getId()) {
					hasNoSameEmail = false;
				//}
			}
			resultSet.close();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			throw new DaoException("L'email choisit existe déjà");
		}
		return hasNoSameEmail;
	}
}
