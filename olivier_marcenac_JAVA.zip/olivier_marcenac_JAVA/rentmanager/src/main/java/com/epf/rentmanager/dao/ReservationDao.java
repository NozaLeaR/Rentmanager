package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.persistence.ConnectionManager;

import org.springframework.stereotype.Repository;

@Repository
public class ReservationDao {

	public ReservationDao() {
	}

	private static final String CREATE_RESERVATION_QUERY = "INSERT INTO Reservation(client_id, vehicule_id, debut, fin) VALUES(?, ?, ?, ?);";
	private static final String DELETE_RESERVATION_QUERY = "DELETE FROM Reservation WHERE id=?;";
	private static final String FIND_RESERVATION_QUERY = "SELECT client_id, vehicule_id, debut, fin FROM Reservation WHERE id=?;";
	private static final String FIND_RESERVATIONBYCLIENT_QUERY = "SELECT id, vehicule_id, debut, fin FROM Reservation WHERE client_id=?;";
	private static final String FIND_RESERVATIONBYVEHICULE_QUERY = "SELECT id, client_id, debut, fin FROM Reservation WHERE vehicule_id=?;";
	private static final String FIND_RESERVATIONS_QUERY = "SELECT id, client_id, vehicule_id, fin, debut FROM Reservation;";
	private static final String UPDATE_RESERVATION_QUERY = "UPDATE Reservation SET client_id = ?, vehicule_id = ?, debut = ?, fin = ? WHERE id = ?;";
	private static final String COUNT_RESERVATIONS_QUERY = "SELECT COUNT(id) AS count FROM Reservation;";


	
	/** 
	 * @param reservation / La réservation à créer
	 * @return int / L'id de la réservation crée
	 * @throws DaoException
	 */
	public int create(Reservation reservation) throws DaoException {
		int id = 0;
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(CREATE_RESERVATION_QUERY,
					id = Statement.RETURN_GENERATED_KEYS);
			ps.setInt(1, reservation.getClient_id());
			ps.setInt(2, reservation.getVehicule_id());
			ps.setDate(3, Date.valueOf(reservation.getDebut()));
			ps.setDate(4, Date.valueOf(reservation.getFin()));
			ps.execute();
			ps.close();
			connection.close();

		} catch (SQLException e) {
			throw new DaoException("Erreur lors de la création");
		}
		return id;
	}

	
	/** 
	 * @param reservation / Une reservation avec un id et tout les paramètres à changer ainsi que ceux non modifié
	 * @throws DaoException
	 */
	public void update(Reservation reservation) throws DaoException {
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(UPDATE_RESERVATION_QUERY);
			ps.setInt(1, reservation.getClient_id());
			ps.setInt(2, reservation.getVehicule_id());
			ps.setDate(3, Date.valueOf(reservation.getDebut()));
			ps.setDate(4, Date.valueOf(reservation.getFin()));
			ps.setInt(5, reservation.getId());

			ps.execute();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			throw new DaoException("Erreur lors de l'update");
		}
	}

	
	/** 
	 * @return int / Le nombre de Reservation dans la Database
	 * @throws DaoException
	 */
	public int count() throws DaoException {
		int count = 0;

		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(COUNT_RESERVATIONS_QUERY);
			ResultSet resultSet = ps.executeQuery();

			while (resultSet.next()) {
				count = resultSet.getInt("count");

			}
			ps.execute();
			resultSet.close();
			ps.close();
			connection.close();

		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw new DaoException("DaoCount");
		}
		return count;
	}

	
	/** 
	 * @param id / L'id de la Reservation à delete
	 * @throws DaoException
	 */
	public void delete(int id) throws DaoException {
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(DELETE_RESERVATION_QUERY);
			ps.setInt(1, id);
			ps.execute();
			ps.close();
			connection.close();

		} catch (SQLException e) {
			throw new DaoException();
		}
	}

	
	/** 
	 * @return List<Reservation> / Une Liste de toutes les Reservations
	 * @throws DaoException
	 */
	public List<Reservation> findAll() throws DaoException {
		List<Reservation> result = new ArrayList<>();
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(FIND_RESERVATIONS_QUERY);

			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Reservation reservation = new Reservation();
				reservation.setId(resultSet.getInt("id"));
				reservation.setClient_id(resultSet.getInt("client_id"));
				reservation.setVehicule_id(resultSet.getInt("vehicule_id"));
				reservation.setDebut(resultSet.getDate("debut").toLocalDate());
				reservation.setFin(resultSet.getDate("fin").toLocalDate());
				result.add(reservation);
			}
			resultSet.close();
			preparedStatement.close();
			connection.close();

		} catch (SQLException e) {
			throw new DaoException("erreur lors du findAll");
		}
		return result;
	}

	
	/** 
	 * @param id / L'id de la Reservation à chercher
	 * @return Optional<Reservation> / La Reservation si elle est trouvée / Null sinon
	 * @throws DaoException
	 */
	public Optional<Reservation> findById(int id) throws DaoException {
		Reservation reservation = new Reservation();

		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(FIND_RESERVATION_QUERY);
			ps.setInt(1, id);
			ps.execute();

			ResultSet resultSet = ps.executeQuery();
			while (resultSet.next()) {
				reservation.setId(id);
				reservation.setClient_id(resultSet.getInt("client_id"));
				reservation.setVehicule_id(resultSet.getInt("vehicule_id"));
				reservation.setDebut(resultSet.getDate("debut").toLocalDate());
				reservation.setFin(resultSet.getDate("fin").toLocalDate());
			}
			resultSet.close();
			ps.close();
			connection.close();

		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw new DaoException("erreur lors du findById");
		}

		return Optional.ofNullable(reservation);

	}

	
	/** 
	 * @param client_id / L'id du Client à chercher
	 * @return List<Reservation> / La liste des Reservations du Client
	 * @throws DaoException
	 */
	public List<Reservation> findByClient_id(int client_id) throws DaoException {

		List<Reservation> result = new ArrayList<>();
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(FIND_RESERVATIONBYCLIENT_QUERY);
			ps.setInt(1, client_id);
			ps.execute();

			ResultSet resultSet = ps.executeQuery();
			while (resultSet.next()) {
				Reservation reservation = new Reservation();
				reservation.setId(resultSet.getInt("id"));
				reservation.setClient_id(client_id);
				reservation.setVehicule_id(resultSet.getInt("vehicule_id"));
				reservation.setDebut(resultSet.getDate("debut").toLocalDate());
				reservation.setFin(resultSet.getDate("fin").toLocalDate());
				result.add(reservation);
			}
			resultSet.close();
			ps.close();
			connection.close();

		} catch (SQLException e) {
			throw new DaoException("erreur lors du findByClient_id");
		}

		return result;

	}

	
	/** 
	 * @param vehicule_id / L'id du Vehicule à chercher
	 * @return List<Reservation> / La liste des Reservations de la voiture
	 * @throws DaoException
	 */
	public List<Reservation> findByVehicule_id(int vehicule_id) throws DaoException {

		List<Reservation> result = new ArrayList<>();
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(FIND_RESERVATIONBYVEHICULE_QUERY);
			ps.setInt(1, vehicule_id);
			ps.execute();

			ResultSet resultSet = ps.executeQuery();
			while (resultSet.next()) {
				Reservation reservation = new Reservation();
				reservation.setId(resultSet.getInt("id"));
				reservation.setClient_id(resultSet.getInt("client_id"));
				reservation.setVehicule_id(vehicule_id);
				reservation.setDebut(resultSet.getDate("debut").toLocalDate());
				reservation.setFin(resultSet.getDate("fin").toLocalDate());
				result.add(reservation);
			}
			resultSet.close();
			ps.close();
			connection.close();

		} catch (SQLException e) {
			throw new DaoException("erreur lors du findByVehicule_id");
		}
		return result;
	}


}
