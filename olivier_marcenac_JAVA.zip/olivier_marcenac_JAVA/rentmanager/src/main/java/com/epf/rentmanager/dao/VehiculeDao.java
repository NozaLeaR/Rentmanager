package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Vehicule;
import com.epf.rentmanager.persistence.ConnectionManager;

import org.springframework.stereotype.Repository;

@Repository
public class VehiculeDao {

	public VehiculeDao() {
	}

	private static final String CREATE_VEHICULE_QUERY = "INSERT INTO VEHICULE(constructeur, modele, nb_places) VALUES(?, ?, ?);";
	private static final String DELETE_VEHICULE_QUERY = "DELETE FROM VEHICULE WHERE id=?;";
	private static final String FIND_VEHICULE_QUERY = "SELECT constructeur, modele, nb_places FROM VEHICULE WHERE id=?;";
	private static final String FIND_VEHICULES_QUERY = "SELECT id, constructeur, modele, nb_places FROM VEHICULE;";
	private static final String UPDATE_VEHICULE_QUERY = "UPDATE Vehicule SET constructeur = ?, modele = ?, nb_places = ? WHERE id = ?;";
	private static final String COUNT_VEHICULES_QUERY = "SELECT COUNT(id) AS count FROM Vehicule;";

	
	/** 
	 * @param vehicule /Le Vehicule à créer
	 * @return int /L'id du Vehicule crée
	 * @throws DaoException
	 */
	public int create(Vehicule vehicule) throws DaoException {
		int id = 0;

		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(CREATE_VEHICULE_QUERY,
					id = Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, vehicule.getConstructeur());
			ps.setString(2, vehicule.getModele());
			ps.setInt(3, vehicule.getNb_places());
			ps.execute();
			ps.close();
			connection.close();

		} catch (SQLException e) {
			throw new DaoException();
		}
		return id;
	}

	
	/** 
	 * @param vehicule / Un Vehicule avec un id et tout les paramètres à changer ainsi que ceux non modifié
	 * @throws DaoException
	 */
	public void update(Vehicule vehicule) throws DaoException {
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(UPDATE_VEHICULE_QUERY);
			ps.setString(1, vehicule.getConstructeur());
			ps.setString(2, vehicule.getModele());
			ps.setInt(3, vehicule.getNb_places());
			ps.setInt(4, vehicule.getId());
			
			ps.execute();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			throw new DaoException();
		}
	}

	
	/** 
	 * @return int / Le nombre de Vehicule dans la Database
	 * @throws DaoException
	 */
	public int count() throws DaoException {
		int count = 0;

		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(COUNT_VEHICULES_QUERY);
			ResultSet resultSet = ps.executeQuery();

			while (resultSet.next()) {
				count = resultSet.getInt("count");

			}
			ps.execute();
			resultSet.close();
			ps.close();
			connection.close();
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw new DaoException("DaoCount");
		}
		return count;
	}

	
	/** 
	 * @param id / L'id du Vehicule à delete
	 * @throws DaoException
	 */
	public void delete(int id) throws DaoException {
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(DELETE_VEHICULE_QUERY);
			ps.setInt(1, id);
			ps.execute();
			ps.close();
			connection.close();

		} catch (SQLException e) {
			throw new DaoException();
		}
	}

	
	/** 
	 * @return List<Vehicule> / La liste de tout les Vehicules de la Database
	 * @throws DaoException
	 */
	public List<Vehicule> findAll() throws DaoException {
		List<Vehicule> result = new ArrayList<>();
		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(FIND_VEHICULES_QUERY);

			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Vehicule vehicule = new Vehicule();
				vehicule.setId(resultSet.getInt("id"));
				vehicule.setConstructeur(resultSet.getString("constructeur"));
				vehicule.setModele(resultSet.getString("modele"));
				vehicule.setNb_places(resultSet.getInt("nb_places"));
				result.add(vehicule);
			}
			resultSet.close();
			preparedStatement.close();
			connection.close();

		} catch (SQLException e) {
			e.printStackTrace();
			throw new DaoException();
		}
		return result;
	}

	
	/** 
	 * @param id / L'id du Vehicule à chercher
	 * @return Optional<Vehicule> / Le Vehicule si il est trouvé / Null sinon
	 * @throws DaoException
	 */
	public Optional<Vehicule> findById(int id) throws DaoException {
		Vehicule vehicule = new Vehicule();

		try {
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement ps = connection.prepareStatement(FIND_VEHICULE_QUERY);
			ps.setInt(1, id);
			ps.execute();

			ResultSet resultSet = ps.executeQuery();
			while (resultSet.next()) {

				vehicule.setId(id);
				vehicule.setConstructeur(resultSet.getString("constructeur"));
				vehicule.setModele(resultSet.getString("modele"));
				vehicule.setNb_places(resultSet.getInt("nb_places"));

			}
			resultSet.close();
			ps.close();
			connection.close();

		} catch (SQLException e) {
			throw new DaoException();
		}
		return Optional.ofNullable(vehicule);

	}

	
	

}
