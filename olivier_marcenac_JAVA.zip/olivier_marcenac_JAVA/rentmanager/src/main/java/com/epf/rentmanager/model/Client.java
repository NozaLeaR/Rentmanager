package com.epf.rentmanager.model;

import java.time.LocalDate;
import java.time.Period;

public class Client extends Object {

	private int id;
	private String nom;
	private String prenom;
	private String email;
	private LocalDate naissance;

	public Client() {

	}

	public Client(String nom, String prenom, String email, LocalDate naissance) {
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.naissance = naissance;
	}

	
	/** 
	 * @return String
	 */
	@Override
	public String toString() {
		return "Client [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", email=" + email + ", naissance="
				+ naissance + "]";
	}

	
	/** 
	 * @return int
	 */
	public int getId() {
		return id;
	}

	
	/** 
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}

	
	/** 
	 * @return String
	 */
	public String getNom() {
		return nom;
	}

	
	/** 
	 * @param nom
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}

	
	/** 
	 * @return String
	 */
	public String getPrenom() {
		return prenom;
	}

	
	/** 
	 * @param prenom
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	
	/** 
	 * @return String
	 */
	public String getEmail() {
		return email;
	}

	
	/** 
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	
	/** 
	 * @return LocalDate
	 */
	public LocalDate getNaissance() {
		return naissance;
	}

	
	/** 
	 * @param naissance
	 */
	public void setNaissance(LocalDate naissance) {
		this.naissance = naissance;
	}

	
	/** 
	 * @return int / L'age du Client
	 */
	public int getAge() {
		LocalDate now=LocalDate.now();
		return Period.between(this.naissance, now).getYears();
	}

	
	/** 
	 * Verifie si le Client a plus de 18 ans
	 * @return boolean / True si age > 18 / False sinon
	 */
	public boolean isLegal() {
		return this.getAge() >= 18;
	}

	
	/** 
	 * Verifie si le Client à un prenom de plus de 3 lettre
	 * @return boolean / True si le prenom du Client à plus de 3 chars / False sinon
	 */
	public boolean isLongFirst() {
		return this.getPrenom().length() >= 3;
	}

	
	/** 
	 * Verifie si le Client à un nom de plus de 3 lettre
	 * @return boolean / True si le nom du Client à plus de 3 chars / False sinon
	 */
	public boolean isLongLast() {
		return this.getNom().length() >= 3;
	}
	
	/** 
	 * Verifie si l'email contient un @.
	 * @return boolean / True si email contient @ / False sinon
	 */
	public boolean hasProperEmail() {
		return this.getEmail().contains("@");
	}

	public Client(int id, String nom, String prenom, String email, LocalDate naissance) {
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.naissance = naissance;
	}

}