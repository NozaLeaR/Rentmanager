package com.epf.rentmanager.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Reservation implements Comparable {

    private int id;
    private int client_id;
    private int vehicule_id;
    private LocalDate debut;
    private LocalDate fin;

    public Reservation(int client_id, int vehicule_id, LocalDate debut, LocalDate fin) {
        this.client_id = client_id;
        this.vehicule_id = vehicule_id;
        this.debut = debut;
        this.fin = fin;
    }

    /**
     * @return int
     */
    public int getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return int
     */
    public int getClient_id() {
        return client_id;
    }

    /**
     * @param client_id
     */
    public void setClient_id(int client_id) {
        this.client_id = client_id;
    }

    /**
     * @return int
     */
    public int getVehicule_id() {
        return vehicule_id;
    }

    /**
     * @param vehicule_id
     */
    public void setVehicule_id(int vehicule_id) {
        this.vehicule_id = vehicule_id;
    }

    /**
     * @return LocalDate
     */
    public LocalDate getDebut() {
        return debut;
    }

    /**
     * @param debut
     */
    public void setDebut(LocalDate debut) {
        this.debut = debut;
    }

    /**
     * @return LocalDate
     */
    public LocalDate getFin() {
        return fin;
    }

    /**
     * @param fin
     */
    public void setFin(LocalDate fin) {
        this.fin = fin;
    }

    /**
     * @return String
     */
    @Override
    public String toString() {
        return "Reservation [id=" + id + ", client_id=" + client_id + ", vehicule_id=" + vehicule_id + ", debut="
                + debut + ", fin=" + fin + "]";
    }

    public Reservation() {
    }

    /**
     * @return int / Le temps en jours de la Reservation
     */
    public int getPeriod() {
        int nb_days = (int) ChronoUnit.DAYS.between(this.getDebut(), this.getFin());
        return nb_days;
    }

    /**
     * Verifie si la Reservation est chronologique
     * 
     * @return boolean / True si debut est après fin / False sinon
     */
    public boolean isNotOrdered() {
        boolean isNotOrdered = false;
        if (this.getDebut().isAfter(this.getFin())) {
            isNotOrdered = true;
        }
        return isNotOrdered;
    }

    /**
     * Verifie si la Reservation dure plus de 7 jours
     * 
     * @return boolean / True si le temps de la Reservation est plus de 7 jours /
     *         False sinon
     */
    public boolean isTooLong() {
        boolean isTooLong = false;
        if (this.getPeriod() > 7) {
            isTooLong = true;
        }
        return isTooLong;
    }

    public Reservation(int id, int client_id, int vehicule_id, LocalDate debut, LocalDate fin) {
        this.id = id;
        this.client_id = client_id;
        this.vehicule_id = vehicule_id;
        this.debut = debut;
        this.fin = fin;
    }

    /**
     * Override de la methode compareTo. Permet le tri des liste de reservation en
     * fonction de Debut.
     * 
     * @param reservation
     * @return int / Le nombre de jours entre les debuts des deux Reservation
     */
    @Override
    public int compareTo(Object reservation) {
        Reservation r = (Reservation) reservation;

        return (int) ChronoUnit.DAYS.between(this.getDebut(), r.getDebut());
    }
}
