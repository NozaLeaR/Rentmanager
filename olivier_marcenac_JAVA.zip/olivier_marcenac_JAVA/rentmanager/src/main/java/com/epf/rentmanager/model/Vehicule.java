package com.epf.rentmanager.model;

public class Vehicule extends Object {

    private int id;
    private String constructeur;
    private String modele;
    private int nb_places;

    public Vehicule() {

    }

    public Vehicule(String constructeur, String modele, int nb_places) {
        this.constructeur = constructeur;
        this.modele = modele;
        this.nb_places = nb_places;
    }

    
    /** 
     * @return int
     */
    public int getId() {
        return id;
    }

    
    /** 
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    
    /** 
     * @return String
     */
    public String getConstructeur() {
        return constructeur;
    }

    
    /** 
     * @param constructeur
     */
    public void setConstructeur(String constructeur) {
        this.constructeur = constructeur;
    }

    
    /** 
     * @return String
     */
    public String getModele() {
        return modele;
    }

    
    /** 
     * @param modele
     */
    public void setModele(String modele) {
        this.modele = modele;
    }

    
    /** 
     * @return int
     */
    public int getNb_places() {
        return nb_places;
    }

    
    /** 
     * @param nb_places
     */
    public void setNb_places(int nb_places) {
        this.nb_places = nb_places;
    }

    
    /** 
     * Verifie si le Vehicule à un modele
     * @return boolean / True si le Vehicule à un modele / False sinon
     */
    public boolean hasProperModele(){
        boolean hasProperModele = false;
        if (this.getModele()!=null) {
            hasProperModele = true;
        }
        return hasProperModele;
    }

    
    /** 
     * Verifie si le Vehicule à un constructeur
     * @return boolean / True si le Vehicule à un constructeur / False sinon
     */
    public boolean hasProperConstructeur(){
        boolean hasProperConstructeur = false;
        if (this.getConstructeur()!=null) {
            hasProperConstructeur = true;
        }
        return hasProperConstructeur;
    }

    
    /** 
     * Verifie si le Vehicule à un nombre de places entre 2 et 9
     * @return boolean / True si Le nombre de places 2 > nb_place > 9 / False sinon
     */
    public boolean hasProperNbPlaces(){
        boolean hasProperNbPlaces = false;
        nb_places=this.getNb_places();
        if (nb_places>2 && nb_places<9 ) {
            hasProperNbPlaces = true;
        }
        return hasProperNbPlaces;
    }


    
    /** 
     * @return String
     */
    @Override
    public String toString() {
        return "Vehicule [id=" + id + ", constructeur=" + constructeur + ", modele=" + modele + ", nb_places=" + nb_places
                + "]";
    }

    public Vehicule(int id, String constructeur, String modele, int nb_places) {
        this.id = id;
        this.constructeur = constructeur;
        this.modele = modele;
        this.nb_places = nb_places;
    }

}