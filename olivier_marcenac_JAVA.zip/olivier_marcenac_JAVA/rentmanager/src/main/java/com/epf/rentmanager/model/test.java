package com.epf.rentmanager.model;

import java.time.LocalDate;

public class test {
    
    public static void main(String[] args) {
        Client client = new Client("olliio","mamzmeae","azeae@azeazea",LocalDate.parse("1999-01-01"));
        System.out.println(client);
    }
}
