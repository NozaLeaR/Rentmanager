package com.epf.rentmanager.service;

import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;

import org.springframework.stereotype.Service;

import com.epf.rentmanager.dao.ClientDao;

@Service
public class ClientService {

	private ClientDao clientDao;
	public static ClientService instance;

	private ClientService(ClientDao clientDao) {
		this.clientDao = clientDao;
	}

	
	/** 
	 * Fait appel à la fonction create du DAO
	 * @param client 
	 * / le client à créer
	 * @return int 
	 * / L'id du client crée
	 * @throws ServiceException
	 */
	public int create(Client client) throws ServiceException {
		if (!client.isLegal()) {
			throw new ServiceException("L'utilisateur doit avoir au moins 18ans");
		} else if (!client.isLongFirst()) {
			throw new ServiceException("Le prénom de l'utilisateur doit avoir 3 charactères");
		} else if (!client.isLongLast()) {
			throw new ServiceException("Le nom de l'utilisateur doit avoir 3 charactères");
		}else if (!client.hasProperEmail()) {
			throw new ServiceException("L'email proposé n'est pas un email");
		} else if(hasNoSameEmail(client)) {
			throw new ServiceException("L'email existe déja");
		}else {
			try {
				String nomMaj = client.getNom().toUpperCase();
				client.setNom(nomMaj);
				return clientDao.create(client);
			} catch (DaoException e) {
				throw new ServiceException("Une erreur a eu lieu lors de la création de l'utilisateur");
			}
		}
	}

	
	/** 
	 * Fait appel à la fonction count du DAO
	 * @return int 
	 * / Le nombre de clients
	 * @throws ServiceException
	 */
	public int count() throws ServiceException {
		int count = 0;
		try {
			count = clientDao.count();
		} catch (DaoException e) {
			throw new ServiceException("Erreur lors du count");
		}
		return count;
	}

	
	/** 
	 * Fait appel à la fonction update du DAO
	 * @param client 
	 * / Une Client avec un id et tout les paramètres à changer ainsi que ceux non modifié
	 * @throws ServiceException
	 */
	public void update(Client client) throws ServiceException {
		if (!client.isLegal()) {
			throw new ServiceException("L'utilisateur doit avoir au moins 18ans");
		} else if (!client.isLongFirst()) {
			throw new ServiceException("Le prénom de l'utilisateur doit avoir 3 charactères");
		} else if (!client.isLongLast()) {
			throw new ServiceException("Le nom de l'utilisateur doit avoir 3 charactères");
		}else if (!client.hasProperEmail()) {
			throw new ServiceException("L'email proposé n'est pas un email");
		} else if(hasNoSameEmail(client)) {
			throw new ServiceException("L'email existe déja");
		}else {
			try {
				String nomMaj = client.getNom().toUpperCase();
				client.setNom(nomMaj);
				clientDao.update(client);
			} catch (DaoException e) {
				throw new ServiceException("Une erreur a eu lieu lors de l'update de l'utilisateur");
			}
		}
	}

	
	/** 
	 * Fait appel à la fonction delete du DAO
	 * @param id 
	 * / L'id du client à delete
	 * @throws ServiceException
	 */
	public void delete(int id) throws ServiceException {
		try {
			clientDao.delete(id);
		} catch (DaoException e) {
			throw new ServiceException("Une erreur a eu lieu lors de la suppression du client");
		}
	}

	
	/** 
	 * Fait appel à la fonction findAll du DAO
	 * @return List<Client>  
	 * / Liste de tout les clients 
	 * @throws ServiceException
	 */
	public List<Client> findAll() throws ServiceException {
		try {
			return clientDao.findAll();
		} catch (DaoException e) {
			throw new ServiceException("Erreur lors du find all");
		}
	}

	
	/** 
	 * Fait appel à la fonction findById du DAO.
	 * Cherche l'id dans la Database.
	 * @param id 
	 * /L'id du client à trouver.
	 * @return Client 
	 * /Le client s'il a été trouvé.
	 * @throws ServiceException
	 */
	public Client findById(int id) throws ServiceException {
		try {
			Optional<Client> client = clientDao.findById(id);
			if (client.isPresent()) {
				return client.get();
			}else{
			throw new ServiceException("L'utilisateur n°" + id + " n'a pas été trouvé dans la base de données");
			}
		} catch (DaoException e) {
			throw new ServiceException("Une erreur a eu lieu lors de la récupération de l'utilisateur");
		}
	}

	
	/** 
	 * Fait appel à la fonction hasNoSameEmail du DAO.
	 * Cherche l'email du client dans la Database.
	 * Fonction de Test.
	 * @param client 
	 * / Le client à tester
	 * @return boolean 
	 * / True si l'email n'existe pas/ False sinon
	 * @throws ServiceException
	 */
	public boolean hasNoSameEmail(Client client) throws ServiceException {
		try {
			return clientDao.hasNoSameEmail(client);
		} catch (DaoException e) {
			throw new ServiceException("Erreur lors du test sur l'email");
		}
	}
}
