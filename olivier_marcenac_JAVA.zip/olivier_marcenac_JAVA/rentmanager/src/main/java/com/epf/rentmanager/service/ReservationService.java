package com.epf.rentmanager.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Reservation;

import org.springframework.stereotype.Service;

@Service
public class ReservationService {

	private ReservationDao reservationDao;
	public static ReservationService instance;

	private ReservationService(ReservationDao reservationDao) {
		this.reservationDao = reservationDao;
	}

	
	/** 
	 * Fait appel à la fonction findAll du DAO.
	 * @return List<Reservation> / La liste des Reservations
	 * @throws ServiceException
	 */
	public List<Reservation> findAll() throws ServiceException {
		try {
			return reservationDao.findAll();
		} catch (DaoException e) {
			throw new ServiceException();
		}
	}

	
	/** 
	 * Fonction de Test.
	 * @param reservation 
	 * / La Reservation à tester.
	 * @return boolean 
	 * / True si le Vehicule de la reservation est deja reservé pendant la periode.
	 * @throws ServiceException
	 */
	public boolean overlap(Reservation reservation) throws ServiceException {
		boolean overlap = false;
		List<Reservation> resultV = new ArrayList<>();
		resultV = findByVehicule_id(reservation.getVehicule_id());

		for (int i = 0; i < resultV.size(); i++) {
			if (reservation.getDebut().isBefore(resultV.get(i).getFin())
					&& resultV.get(i).getDebut().isAfter(reservation.getFin())) {
				overlap = true;
			}
		}
		return overlap;
	}

	
	/** 
	 * Fonction de Test.
	 * Test si le Vehicule n'est pas occupé pendant de plus de 30 jours.
	 * @param reservation
	 *  / La Reservation à tester
	 * @return boolean 
	 * @throws ServiceException
	 */
	public boolean reservationSansPause(Reservation reservation) throws ServiceException {

		List<Reservation> resultV = new ArrayList<>();
		resultV = findByVehicule_id(reservation.getVehicule_id());
		resultV.add(reservation);
		Collections.sort(resultV);
		Collections.reverse(resultV);
		boolean reservationSansPause = false;

		final int DaysUntilPause = 30;
		final int maxReservationDays = 7;
		final int minReservationsUntilPause = (int) DaysUntilPause / maxReservationDays;

		if (resultV.size() > minReservationsUntilPause) {
			LocalDate old_days;
			LocalDate new_days;

			int index = 0;
			for (int i = 0; i < resultV.size(); i++) {
				if (resultV.get(i).getId() == reservation.getId()) {
					index = i;
				}
			}

			new_days = getNewDate(resultV, index);
			old_days = getOldDate(resultV, index);

			int s = (int) ChronoUnit.DAYS.between(old_days, new_days);
			if (s > DaysUntilPause) {
				reservationSansPause = true;
			}
		}
		return reservationSansPause;
	}

	
	/** 
	 * Recupère la date la plus nouvelle dans une liste de Reservation tel que le vehicule n'a pas eu de pause.
	 * @param resultV / La liste de Reservation.
	 * @param index / L'index à partir de laquelle la fonction teste.
	 * @return LocalDate
	 */
	public LocalDate getNewDate(List<Reservation> resultV, int index) {
		LocalDate right_days = resultV.get(index).getFin();
		int n = 0;
		while (index + n < resultV.size() - 1) {
			if (resultV.get(index + n).getFin().compareTo(resultV.get(index + n + 1).getDebut()) == -1) {
				right_days = resultV.get(index + n + 1).getFin();
			} else {
				break;
			}
			n++;
		}
		return right_days;
	}

	
	/** 
	 * Recupère la date la plus vielle dans une liste de Reservation tel que le vehicule n'a pas eu de pause.
	 * @param resultV / La liste de Reservation. 
	 * @param index / L'index à partir de laquelle la fonction teste.
	 * @return LocalDate
	 */
	public LocalDate getOldDate(List<Reservation> resultV, int index) {
		LocalDate old_days = resultV.get(index).getDebut();
		int n = 0;
		while (index - n > 0) {
			if (resultV.get(index - n).getDebut().compareTo(resultV.get(index - n - 1).getFin()) == 1) {
				old_days = resultV.get(index - n - 1).getDebut();
			} else {
				break;
			}
			n++;
		}
		return old_days;
	}

	
	/** 
	 * Fait appel à la fonction create du DAO.
	 * @param reservation / La réservation à créer.
	 * @return int / L'id de la réservation crée.
	 * @throws ServiceException
	 */
	public int create(Reservation reservation) throws ServiceException {

		if (reservation.isNotOrdered()) {
			throw new ServiceException("La date de début est après la date de fin");
		} else if (reservation.isTooLong()) {
			throw new ServiceException("La reservation dure plus de 7 jours");
		} else if (overlap(reservation)) {
			throw new ServiceException("La voiture choisit est déjà réservée pour cette période");
		} else if (reservationSansPause(reservation)) {
			throw new ServiceException("La voiture choisit est reservé pendant 30 jours sans pause");
		} else {
			try {
				return reservationDao.create(reservation);
			} catch (DaoException e) {
				throw new ServiceException("Une erreur a eu lieu lors de la création de la reservation");
			}
		}
	}

	
	/** 
	 * Fait appel à la fonction update du DAO.
	 * @param reservation / Une reservation avec un id et tout les paramètres à changer ainsi que ceux non modifié.
	 * @throws ServiceException
	 */
	public void update(Reservation reservation) throws ServiceException {
		if (reservation.isNotOrdered()) {
			throw new ServiceException("La date de début est après la date de fin");
		} else if (reservation.isTooLong()) {
			throw new ServiceException("La reservation dure plus de 7 jours");
		} else if (overlap(reservation)) {
			throw new ServiceException("La voiture choisit est déjà réservée pour cette période");
		} else if (reservationSansPause(reservation)) {
			throw new ServiceException("La voiture choisit est reservé pendant 30 jours sans pause");
		} else {
			try {
				reservationDao.update(reservation);
			} catch (DaoException e) {
				throw new ServiceException("Une erreur a eu lieu lors de l'update de la reservation");
			}
		}
	}

	
	/** 
	 * Fait appel à la fonction count du DAO.
	 * @return int / Le nombre de Reservations dans la Database.
	 * @throws ServiceException
	 */
	public int count() throws ServiceException {
		int count = 0;
		try {
			count = reservationDao.count();
		} catch (DaoException e) {
			throw new ServiceException("Erreur lors du count");
		}
		return count;
	}

	
	/** 
	 * Fait appel à la fonction delete du DAO.
	 * @param id / L'id de la reservation à delete.
	 * @throws ServiceException
	 */
	public void delete(int id) throws ServiceException {
		try {
			reservationDao.delete(id);
		} catch (DaoException e) {
			throw new ServiceException("Une erreur a eu lieu lors de la suppression de la reservation");
		}
	}

	
	/** 
	 * Fait appel à la fonction findById du DAO.
	 * @param id / L'id de la Reservation à chercher.
	 * @return Reservation / La Reservation associé à l'id.
	 * @throws ServiceException
	 */
	public Reservation findById(int id) throws ServiceException {
		try {
			Optional<Reservation> reservation = reservationDao.findById(id);
			if (reservation.isPresent()) {
				return reservation.get();
			} else {
				throw new ServiceException("la reservation n°" + id + " n'a pas été trouvé dans la base de données");
			}
		} catch (DaoException e) {
			throw new ServiceException("Une erreur a eu lieu lors de la récupération de la reservation");
		}
	}

	
	/** 
	 * Fait appel à la fonction findByClient_id du DAO.
	 * @param client_id / L'id du client à chercher.
	 * @return List<Reservation> / La liste des reservations qui on pour client client_id.
	 * @throws ServiceException
	 */
	public List<Reservation> findByClient_id(int client_id) throws ServiceException {
		try {
			return reservationDao.findByClient_id(client_id);
		} catch (DaoException e) {
			throw new ServiceException("Erreur lors du find by client id");
		}
	}

	
	/** 
	 * Fait appel à la fonction findByVehicule_id du DAO.
	 * @param vehicule_id / L'id du Vehicule à chercher.
	 * @return List<Reservation> / La liste des reservations qui on pour vehicule vehicule_id.
	 * @throws ServiceException
	 */
	public List<Reservation> findByVehicule_id(int vehicule_id) throws ServiceException {
		try {
			return reservationDao.findByVehicule_id(vehicule_id);
		} catch (DaoException e) {
			throw new ServiceException("Erreur lors du find by vehicule id");
		}
	}
}
