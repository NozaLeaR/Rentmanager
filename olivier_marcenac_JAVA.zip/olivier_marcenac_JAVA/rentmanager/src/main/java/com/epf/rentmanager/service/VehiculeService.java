package com.epf.rentmanager.service;

import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Vehicule;

import org.springframework.stereotype.Service;

import com.epf.rentmanager.dao.VehiculeDao;

@Service
public class VehiculeService {

	private VehiculeDao vehiculeDao;
	public static VehiculeService instance;

	private VehiculeService(VehiculeDao vehiculeDao) {
		this.vehiculeDao = vehiculeDao;
	}

	/**
	 * Fait appel à la fonction create du DAO.
	 * @param vehicule /Le Vehicule à créer
	 * @return int /L'id du Vehicule crée
	 * @throws ServiceException
	 */
	public int create(Vehicule vehicule) throws ServiceException {
		if (!vehicule.hasProperModele()) {
			throw new ServiceException("Le modele du vehicule n'est pas bon");
		} else if (!vehicule.hasProperConstructeur()) {
			throw new ServiceException("Le constructeur du vehicule n'est pas bon");
		} else if (!vehicule.hasProperNbPlaces()) {
			throw new ServiceException("Le nombre de places du vehicule n'est pas bon");
		} else {
			try {
				return vehiculeDao.create(vehicule);
			} catch (DaoException e) {
				throw new ServiceException("Une erreur a eu lieu lors de la création du vehicule");
			}
		}
	}

	/**
	 * Fait appel à la fonction update du DAO.
	 * @param vehicule / Un Vehicule avec un id et tout les paramètres à changer ainsi que ceux non modifié
	 * @throws ServiceException
	 */
	public void update(Vehicule vehicule) throws ServiceException {
		if (!vehicule.hasProperModele()) {
			throw new ServiceException("Le modele du vehicule n'est pas bon");
		} else if (!vehicule.hasProperConstructeur()) {
			throw new ServiceException("Le constructeur du vehicule n'est pas bon");
		} else if (!vehicule.hasProperNbPlaces()) {
			throw new ServiceException("Le nombre de places du vehicule n'est pas bon");
		} else {
			try {
				vehiculeDao.update(vehicule);
			} catch (DaoException e) {
				throw new ServiceException("Une erreur a eu lieu lors de l'update création du vehicule");
			}
		}
	}

	/** 
	 * Fait appel à la fonction count du DAO.
	 * @return int / Le nombre de Vehicule dans la Database.
	 * @throws ServiceException
	 */
	public int count() throws ServiceException {
		int count = 0;
		try {
			count = vehiculeDao.count();
		} catch (DaoException e) {
			throw new ServiceException("serviceCount");
		}
		return count;
	}

	/** 
	 * Fait appel à la fonction delete du DAO.
	 * @param id / L'id du Vehicule à delete
	 * @throws ServiceException
	 */
	public void delete(int id) throws ServiceException {
		try {
			vehiculeDao.delete(id);
		} catch (DaoException e) {
			throw new ServiceException("Une erreur a eu lieu lors de la suppression du vehicule");
		}
	}
	
	/** 
	 * Fait appel à la fonction finById du DAO.
	 * @param id / L'id du Vehicule à chercher.
	 * @return Vehicule / Le Vehicule si il est trouvé / Erreur sinon.
	 * @throws ServiceException
	 */
	public Vehicule findById(int id) throws ServiceException {
		try {
			Optional<Vehicule> vehicule = vehiculeDao.findById(id);
			if (vehicule.isPresent()) {
				return vehicule.get();
			} else {
				throw new ServiceException("L'utilisateur n°" + id + " n'a pas été trouvé dans la base de données");
			}
		} catch (DaoException e) {
			System.out.println(e.getMessage());
			throw new ServiceException("Une erreur a eu lieu lors de la récupération de l'utilisateur");
		}
	}
	
	/** 
	 * Fait appel à la fonction findAll du DAO.
	 * @return List<Vehicule> / La liste de tout les Vehicules de la Database.
	 * @throws ServiceException
	 */
	public List<Vehicule> findAll() throws ServiceException {
		try {
			return vehiculeDao.findAll();
		} catch (DaoException e) {
			throw new ServiceException();
		}
	}
}
