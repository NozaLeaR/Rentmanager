package com.epf.rentmanager.ui.Servlets;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.service.ClientService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

@WebServlet("/clients/create")
public class ClientCreateServlet extends HttpServlet {

    public ClientCreateServlet() {
    }

    @Autowired
    ClientService clientService;

    
    /** 
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        super.init();
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    
    /** 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/clients/create.jsp");
        dispatcher.forward(request, response);
    }

    
    /** 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nom;
        String prenom;
        String email;
        LocalDate naissance;

        nom = request.getParameter("last_name");
        prenom = request.getParameter("first_name");
        email = request.getParameter("email");
        naissance = LocalDate.parse(request.getParameter("naissance"));

        Client client = new Client(nom, prenom, email, naissance);
        try {
            clientService.create(client);
        } catch (ServiceException e) {
            // TODO: handle exception
        }
        response.sendRedirect("http://localhost:8080/rentmanager/clients");

    }

}