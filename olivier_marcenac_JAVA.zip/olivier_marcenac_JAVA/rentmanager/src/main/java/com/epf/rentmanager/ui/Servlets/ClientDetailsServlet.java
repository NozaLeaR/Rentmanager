package com.epf.rentmanager.ui.Servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicule;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.ReservationService;
import com.epf.rentmanager.service.VehiculeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

@WebServlet("/clients/details")
public class ClientDetailsServlet extends HttpServlet {

    public ClientDetailsServlet() {
    }

    @Autowired
    VehiculeService vehiculeService;
    @Autowired
    ReservationService reservationService;
    @Autowired
    ClientService clientService;

    
    /** 
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        super.init();
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    
    /** 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.valueOf(request.getQueryString().substring(3));

        List<Vehicule> listV = new ArrayList<>();
        List<Reservation> listR = new ArrayList<>();

        Client client = new Client();
        try {
            client = clientService.findById(id);
        } catch (ServiceException e) {
        }

        try {
            listR = reservationService.findByClient_id(id);
        } catch (ServiceException e) {
        }

        try {
            for (int i = 0; i < listR.size(); i++) {
                listV.add(vehiculeService.findById(listR.get(i).getVehicule_id()));
            }
        } catch (ServiceException e) {
        }

        request.setAttribute("prenom", client.getPrenom());
        request.setAttribute("nom", client.getNom());
        request.setAttribute("email", client.getEmail());
        request.setAttribute("naissance", client.getNaissance());

        request.setAttribute("reservations", listR);
        request.setAttribute("vehicules", listV);

        request.setAttribute("Vsize", listV.size());
        request.setAttribute("Rsize", listR.size());

        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/clients/details.jsp");
        dispatcher.forward(request, response);
    }

    
    /** 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

}