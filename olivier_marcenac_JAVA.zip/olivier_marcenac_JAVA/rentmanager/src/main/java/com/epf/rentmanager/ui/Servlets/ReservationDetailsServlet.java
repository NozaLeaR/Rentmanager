package com.epf.rentmanager.ui.Servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicule;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.ReservationService;
import com.epf.rentmanager.service.VehiculeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

@WebServlet("/reservations/details")
public class ReservationDetailsServlet extends HttpServlet {

    public ReservationDetailsServlet() {
    }

    @Autowired
    VehiculeService vehiculeService;
    @Autowired
    ReservationService reservationService;
    @Autowired
    ClientService clientService;
    
    /** 
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        super.init();
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }
    
    /** 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.valueOf(request.getQueryString().substring(3));

        Reservation reservation = new Reservation();
        try {
            reservation = reservationService.findById(id);
        } catch (ServiceException e) {
        }
        Client client = new Client();
        try {
            client = clientService.findById(reservation.getClient_id());
        } catch (ServiceException e) {
        }
        Vehicule vehicule = new Vehicule();
        try {
            vehicule = vehiculeService.findById(reservation.getVehicule_id());
        } catch (ServiceException e) {
        }


        request.setAttribute("client_id", client.getId());
        request.setAttribute("prenom", client.getPrenom());
        request.setAttribute("nom", client.getNom());
        request.setAttribute("email", client.getEmail());
        request.setAttribute("naissance", client.getNaissance());
        
        request.setAttribute("vehicule_id", client.getId());
        request.setAttribute("constructeur", vehicule.getConstructeur());
        request.setAttribute("modele", vehicule.getModele());
        request.setAttribute("nb_place", vehicule.getNb_places());

        request.setAttribute("reservation_id", client.getId());
        request.setAttribute("debut", reservation.getDebut());
        request.setAttribute("fin", reservation.getDebut());
       

        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/reservations/details.jsp");
        dispatcher.forward(request, response);
    }

    
    /** 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

}