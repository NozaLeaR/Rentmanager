package com.epf.rentmanager.ui.Servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.service.ReservationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

@WebServlet("/reservations")
public class ReservationListServlet extends HttpServlet {

    public ReservationListServlet() {
    }
    @Autowired
    ReservationService reservationService;
    
    /** 
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        super.init();
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    
    /** 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Reservation> list = new ArrayList<>();
        try {
            
            list = reservationService.findAll();
        } catch (ServiceException e) {
        }
        request.setAttribute("reservations", list);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/reservations/list.jsp");
        dispatcher.forward(request, response);
    }

    

}
