package com.epf.rentmanager.ui.Servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Vehicule;
import com.epf.rentmanager.service.VehiculeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

@WebServlet("/vehicules")
public class VehiculeListServlet extends HttpServlet {

    public VehiculeListServlet() {
    }

    @Autowired
    VehiculeService vehiculeService;
    
    /** 
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        super.init();
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }
    
    
    /** 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Vehicule> list = new ArrayList<>();
        try {
            
            list = vehiculeService.findAll();
        } catch (ServiceException e) {
        }
        request.setAttribute("vehicules", list);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/vehicules/list.jsp");
        dispatcher.forward(request, response);
    }

    

}
