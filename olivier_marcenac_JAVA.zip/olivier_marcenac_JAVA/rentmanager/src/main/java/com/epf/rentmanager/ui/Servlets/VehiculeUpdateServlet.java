package com.epf.rentmanager.ui.Servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Vehicule;
import com.epf.rentmanager.service.VehiculeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

@WebServlet("/vehicules/update")
public class VehiculeUpdateServlet extends HttpServlet {

    private int id;

    public VehiculeUpdateServlet() {
    }
    @Autowired
    VehiculeService vehiculeService;
    
    /** 
     * @throws ServletException
     */
    @Override
    public void init() throws ServletException {
        super.init();
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }
    
    /** 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                
        id = Integer.valueOf(request.getQueryString().substring(3));
        request.setAttribute("id", id);
        Vehicule vehicule = new Vehicule();
        try {
            vehicule = vehiculeService.findById(id);
        } catch (ServiceException e) {
            // TODO: handle exception
        }

        request.setAttribute("manufacturer", vehicule.getConstructeur());
        request.setAttribute("modele", vehicule.getModele());
        request.setAttribute("seats", vehicule.getNb_places());

        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/vehicules/update.jsp");
        dispatcher.forward(request, response);
    }

    
    /** 
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String constructeur;
        String modele;
        int nb_places;

        constructeur = request.getParameter("manufacturer");
        modele = request.getParameter("modele");
        nb_places = Integer.valueOf(request.getParameter("seats"));

        Vehicule vehicule = new Vehicule(id, constructeur, modele, nb_places);

        try {
            vehiculeService.update(vehicule);
        } catch (ServiceException e) {
            // TODO: handle exception
        }
        response.sendRedirect("http://localhost:8080/rentmanager/vehicules");

    }

}