package com.epf.rentmanager.ui.cli;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.epf.rentmanager.configuration.AppConfiguration;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.utils.IOUtils;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ClientController {
    private ClientService clientService;

    private ClientController() {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfiguration.class);
        ClientService clientService = context.getBean(ClientService.class);
        this.clientService = clientService;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        ClientController cmd = new ClientController();
        boolean continuer = true;

        while (continuer) {
            int choix = IOUtils.readInt("choix");

            switch (choix) {
            case 1:
                cmd.createClient();
                break;
            case 2:
                cmd.showAllClients();
                break;
            case 3:
                cmd.updateClient();
                break;
            case 4:
                cmd.deleteClient();
                break;
            case 5:
                cmd.count();
                break;
            case 6:
                cmd.ShowClient();
                break;
            default:
                continuer = false;
                break;

            }
        }

    }

    /**
     * @return int
     */
    public int count() {
        int count = 0;
        try {
            count = this.getClientService().count();
        } catch (ServiceException e) {
            System.out.println("ControllerCount");
            e.printStackTrace();
        }
        System.out.println(count);
        return count;
    }

    /**
     * @return ClientService
     */
    public ClientService getClientService() {
        return clientService;
    }

    public void createClient() {
        String nom = IOUtils.readString("nom", true);
        String prenom = IOUtils.readString("prenom", true);
        String email = null;

        // Validation technique (la variable représente un email)
        do {
            email = IOUtils.readString("email", true);
        } while (!email.contains("@"));
        LocalDate naissance = IOUtils.readDate("dd/MM/yyyy", true);
        Client client = new Client(nom, prenom, email, naissance);
        try {
            this.getClientService().create(client);
            System.out.println("L'utilisateur a bien été créé");
        } catch (ServiceException e) {
            e.printStackTrace();
        }
    }

    public void updateClient() {
        int id = IOUtils.readInt("id");
        String nom = IOUtils.readString("nom", true);
        String prenom = IOUtils.readString("prenom", true);
        String email = null;

        // Validation technique (la variable représente un email)
        do {
            email = IOUtils.readString("email", true);
        } while (!email.contains("@"));
        LocalDate naissance = IOUtils.readDate("dd/MM/yyyy", true);
        Client client = new Client(id, nom, prenom, email, naissance);
        try {
            this.getClientService().update(client);
            System.out.println("L'utilisateur a bien été update");
        } catch (ServiceException e) {
            e.printStackTrace();
        }
    }

    public void deleteClient() {
        int id = IOUtils.readInt("id");
        try {
            this.getClientService().delete(id);
            System.out.println("L'utilisateur a bien été delete");
        } catch (ServiceException e) {
            e.printStackTrace();
        }
    }

    public void showAllClients() {
        List<Client> list = new ArrayList<>();
        try {
            list = this.clientService.findAll();
        } catch (ServiceException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        for (int i = 0; i < list.size(); i++) {
            System.out.println("showAllClients :" + i + "\n" + list.get(i).toString());
        }
    }

    public void ShowClient() {
        int id = IOUtils.readInt("id");
        Client client = new Client();
        try {
            client = this.clientService.findById(id);
        } catch (ServiceException e) {
            e.printStackTrace();
        }
        System.out.println("showClient :\n" + client);
    }

}