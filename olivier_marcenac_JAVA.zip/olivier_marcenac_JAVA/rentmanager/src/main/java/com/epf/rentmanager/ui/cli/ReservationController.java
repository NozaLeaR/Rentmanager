package com.epf.rentmanager.ui.cli;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.epf.rentmanager.configuration.AppConfiguration;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.service.ReservationService;
import com.epf.rentmanager.utils.IOUtils;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ReservationController {

    private ReservationService reservationService;
    private static ReservationController cmd;

    private ReservationController() {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfiguration.class);
        ReservationService reservationService = context.getBean(ReservationService.class);
        this.reservationService = reservationService;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        cmd = new ReservationController();
        boolean continuer = true;
        while (continuer) {
            int choix = IOUtils.readInt("\nchoix : ");

            switch (choix) {
            case 1:
                cmd.createReservation();
                break;
            case 2:
                cmd.deleteReservation();
                break;
            case 3:
                cmd.updateReservation();
                break;
            case 4:
                cmd.showAllReservations();
                break;
            case 5:
                cmd.showReservationOfClient();
                break;
            case 6:
                cmd.showReservationOfVehicule();
                break;
            case 7:
                cmd.showReservation();
                break;
            case 8:
                cmd.count();
                break;
            default:
                continuer = false;
                break;

            }
        }
    }

    /**
     * @return ReservationService
     */
    public ReservationService getReservationService() {
        return reservationService;
    }

    public void createReservation() {
        int client_id = IOUtils.readInt("client_id");
        int vehicule_id = IOUtils.readInt("vehicule_id");
        LocalDate debut = IOUtils.readDate("dd/MM/yyyy", true);
        LocalDate fin = IOUtils.readDate("dd/MM/yyyy", true);
        Reservation reservation = new Reservation(client_id, vehicule_id, debut, fin);
        try {
            cmd.getReservationService().create(reservation);
            System.out.println("La reservation a bien été créé");
        } catch (ServiceException e) {
            e.printStackTrace();
        }
    }

    public void count() {
        try {
            int c = this.getReservationService().count();
            System.out.println("Nombre de Reservations : " + c);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateReservation() {
        int id = IOUtils.readInt("id");
        int client_id = IOUtils.readInt("client_id");
        int vehicule_id = IOUtils.readInt("vehicule_id");
        LocalDate debut = IOUtils.readDate("dd/MM/yyyy", true);
        LocalDate fin = IOUtils.readDate("dd/MM/yyyy", true);
        Reservation reservation = new Reservation(id, client_id, vehicule_id, debut, fin);
        try {
            cmd.getReservationService().update(reservation);
            System.out.println("La reservation a bien été update");
        } catch (ServiceException e) {
            e.printStackTrace();
        }
    }

    public void deleteReservation() {
        int id = IOUtils.readInt("id");
        try {
            this.reservationService.delete(id);
            System.out.println("La reservation a bien été supprimée");
        } catch (ServiceException e) {
            e.printStackTrace();
        }
    }

    public void showAllReservations() {
        List<Reservation> list = new ArrayList<>();
        try {
            list = this.reservationService.findAll();
        } catch (ServiceException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i).toString());
        }
    }

    public void showReservationOfClient() {
        int client_id = IOUtils.readInt("client_id");
        List<Reservation> list = new ArrayList<>();
        try {
            list = this.reservationService.findByClient_id(client_id);
        } catch (ServiceException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i).toString());
        }
    }

    public void showReservation() {
        int id = IOUtils.readInt("id");
        Reservation reservation = new Reservation();
        try {
            reservation = this.reservationService.findById(id);
        } catch (ServiceException e) {
            e.printStackTrace();
        }
        System.out.println(reservation);
    }

    public void showReservationOfVehicule() {
        int vehicule_id = IOUtils.readInt("vehicule_id");
        List<Reservation> list = new ArrayList<>();
        try {
            list = this.reservationService.findByVehicule_id(vehicule_id);
        } catch (ServiceException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i).toString());
        }
    }
}
