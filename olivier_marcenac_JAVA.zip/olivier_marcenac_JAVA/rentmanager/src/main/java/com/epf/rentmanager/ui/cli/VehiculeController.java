package com.epf.rentmanager.ui.cli;

import java.util.ArrayList;
import java.util.List;

import com.epf.rentmanager.configuration.AppConfiguration;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Vehicule;
import com.epf.rentmanager.service.VehiculeService;
import com.epf.rentmanager.utils.IOUtils;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class VehiculeController {

    private VehiculeService vehiculeService;
    private static VehiculeController cmd;

    private VehiculeController() {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfiguration.class);
        VehiculeService vehiculeService = context.getBean(VehiculeService.class);
        this.vehiculeService = vehiculeService;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        cmd = new VehiculeController();
        boolean continuer = true;
        while (continuer) {
            int choix = IOUtils.readInt("\nchoix : ");

            switch (choix) {
            case 1:
                cmd.createVehicule();
                break;
            case 2:
                cmd.showAllVehicules();
                break;
            case 3:
                cmd.showVehicule();
                break;
            case 4:
                cmd.updateVehicule();
                break;
            case 5:
                cmd.count();
                break;
            case 6:
                cmd.deleteVehicule();
                break;
            default:
                continuer = false;
                break;

            }

        }

    }

    /**
     * @return VehiculeService
     */
    public VehiculeService getVehiculeService() {
        return vehiculeService;
    }

    public void createVehicule() {

        String constructeur = IOUtils.readString("constructeur", true);
        String modele = IOUtils.readString("modele", true);
        int nb_places = IOUtils.readInt("nb_places");

        Vehicule vehicule = new Vehicule(constructeur, modele, nb_places);
        try {
            this.getVehiculeService().create(vehicule);
            System.out.println("Le vehicule a bien été créé");
        } catch (ServiceException e) {
            e.printStackTrace();
        }
    }

    public void updateVehicule() {

        int id = IOUtils.readInt("id");
        String constructeur = IOUtils.readString("constructeur", true);
        String modele = IOUtils.readString("modele", true);
        int nb_places = IOUtils.readInt("nb_places");

        Vehicule vehicule = new Vehicule(id, constructeur, modele, nb_places);
        try {
            this.getVehiculeService().update(vehicule);
            System.out.println("Le vehicule a bien été update");
        } catch (ServiceException e) {
            e.printStackTrace();
        }
    }

    public void showAllVehicules() {

        List<Vehicule> list = new ArrayList<>();
        try {
            list = this.getVehiculeService().findAll();
        } catch (ServiceException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
    }

    public void showVehicule() {
        int id = IOUtils.readInt("id");
        Vehicule v = new Vehicule();
        try {
            v = this.getVehiculeService().findById(id);
        } catch (ServiceException e) {
            e.printStackTrace();
        }
        System.out.println(v);
    }

    public void count() {
        try {
            int c = this.getVehiculeService().count();
            System.out.println("Nombre de Vehicules : " + c);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteVehicule() {
        int id = IOUtils.readInt("id");
        try {
            this.getVehiculeService().delete(id);
            System.out.println("Le vehicule " + id + " a bien été delete");
        } catch (ServiceException e) {
            e.printStackTrace();
        }
    }
}
