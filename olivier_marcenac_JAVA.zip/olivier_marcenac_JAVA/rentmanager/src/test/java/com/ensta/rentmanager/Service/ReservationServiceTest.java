package com.ensta.rentmanager.Service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.time.LocalDate;

import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.service.ReservationService;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ReservationServiceTest {
    @InjectMocks
    private ReservationService reservationService;
    @Mock
    private ReservationDao reservationDao;

    /**
     * @throws DaoException
     */
    @Test
    public void findAll() throws DaoException {
        // When
        when(reservationDao.findAll()).thenThrow(DaoException.class);
        // Then
        assertThrows(ServiceException.class, () -> reservationService.findAll());
    }

    /**
     * @throws DaoException
     */
    @Test
    public void findById() throws DaoException {
        // When
        when(reservationDao.findById(1)).thenThrow(DaoException.class);
        // Then
        assertThrows(ServiceException.class, () -> reservationService.findById(1));
    }

    /**
     * @throws DaoException
     */
    @Test
    public void findByReservation_Id() throws DaoException {
        // When
        when(reservationDao.findById(1)).thenThrow(DaoException.class);
        // Then
        assertThrows(ServiceException.class, () -> reservationService.findById(1));
    }

    /**
     * @throws DaoException
     */
    @Test
    public void create() throws DaoException {
        // Given
        Reservation reservation = new Reservation(1, 1, 1, LocalDate.parse("2000-01-01"),
                LocalDate.parse("2000-01-06"));
        // When
        when(reservationDao.create(reservation)).thenThrow(DaoException.class);
        // Then
        assertThrows(ServiceException.class, () -> reservationService.create(reservation));
    }

    @Test
    public void count_dao_throws_exception() throws DaoException {
        // When
        when(reservationDao.count()).thenThrow(DaoException.class);
        // Then
        assertThrows(ServiceException.class, () -> reservationService.count());
    }

    @Test
    public void delete_dao_throws_exception() throws DaoException {
        // When
        doThrow(new DaoException("Exception occured")).when(reservationDao).delete(1);
        // Then
        assertThrows(ServiceException.class, () -> reservationService.delete(1));
    }

    @Test
    public void update_dao_throws_exception() throws DaoException {
        // Given
        Reservation reservation = new Reservation(1, 1, 1, LocalDate.parse("2000-01-01"),
                LocalDate.parse("2000-01-06"));
        // When
        doThrow(new DaoException("Exception occured")).when(reservationDao).update(reservation);
        // Then
        assertThrows(ServiceException.class, () -> reservationService.update(reservation));
    }
}
