package com.ensta.rentmanager.Service;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import com.epf.rentmanager.dao.VehiculeDao;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Vehicule;
import com.epf.rentmanager.service.VehiculeService;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class VehiculeServiceTest {
    @InjectMocks
    private VehiculeService vehiculeService;
    @Mock
    private VehiculeDao vehiculeDao;

    /**
     * @throws DaoException
     */
    @Test
    public void find_All_dao_throws_exception() throws DaoException {
        // When
        when(vehiculeDao.findAll()).thenThrow(DaoException.class);
        // Then
        assertThrows(ServiceException.class, () -> vehiculeService.findAll());
    }

    /**
     * @throws DaoException
     */
    @Test
    public void find_by_id_dao_throws_exception() throws DaoException {
        // When
        when(vehiculeDao.findById(1)).thenThrow(DaoException.class);
        // Then
        assertThrows(ServiceException.class, () -> vehiculeService.findById(1));
    }

    /**
     * @throws DaoException
     */
    @Test
    public void create_dao_throws_exception() throws DaoException {
        // Given
        Vehicule vehicule = new Vehicule("renault", "clio", 4);
        
        // When
        when(vehiculeDao.create(vehicule)).thenThrow(DaoException.class);
        // Then
        assertThrows(ServiceException.class, () -> vehiculeService.create(vehicule));
    }

    @Test
    public void count_dao_throws_exception() throws DaoException {
        // When
        when(vehiculeDao.count()).thenThrow(DaoException.class);
        // Then
        assertThrows(ServiceException.class, () -> vehiculeService.count());
    }

    @Test
    public void delete_dao_throws_exception() throws DaoException {
        // When
        doThrow(new DaoException("Exception occured")).when(vehiculeDao).delete(1);
        // Then
        assertThrows(ServiceException.class, () -> vehiculeService.delete(1));
    }

    @Test
    public void update_dao_throws_exception() throws DaoException {
        // Given
        Vehicule vehicule = new Vehicule("renault", "clio", 4);
        // When
        doThrow(new DaoException("Exception occured")).when(vehiculeDao).update(vehicule);
        // Then
        assertThrows(ServiceException.class, () -> vehiculeService.update(vehicule));
    }
}