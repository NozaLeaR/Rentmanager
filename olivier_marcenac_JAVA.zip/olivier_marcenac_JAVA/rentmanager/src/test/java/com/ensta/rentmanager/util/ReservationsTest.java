package com.ensta.rentmanager.util;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import com.epf.rentmanager.model.Reservation;

import org.junit.jupiter.api.Test;

public class ReservationsTest {
    @Test
    void is_Too_Long_True_Test() {
        // Given
        Reservation legalReservation = new Reservation(1 , 1, 1, LocalDate.parse("2000-01-01"),
                LocalDate.parse("2000-01-11"));
        // Then
        assertTrue(legalReservation.isTooLong());
    }

    @Test
    void is_Too_Long_False_Test() {
        // Given
        Reservation legalReservation = new Reservation(1 ,1, 1, LocalDate.parse("2000-01-01"),
                LocalDate.parse("2000-01-06"));
        // Then
        assertFalse(legalReservation.isTooLong());
    }

    @Test
    void is_Not_Ordered_True_Test() {
        // Given
        Reservation legalReservation = new Reservation(1 ,1, 1, LocalDate.parse("2000-01-06"),
                LocalDate.parse("2000-01-01"));
        // Then
        assertTrue(legalReservation.isNotOrdered());
    }

    @Test
    void is_Not_Ordered_False_Test() {
        // Given
        Reservation legalReservation = new Reservation(1 ,1, 1, LocalDate.parse("2000-01-01"),
                LocalDate.parse("2000-01-06"));
        // Then
        assertFalse(legalReservation.isNotOrdered());
    }
}
