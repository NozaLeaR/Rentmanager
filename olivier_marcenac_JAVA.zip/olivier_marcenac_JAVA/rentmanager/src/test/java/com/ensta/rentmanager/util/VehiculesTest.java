package com.ensta.rentmanager.util;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

import com.epf.rentmanager.model.Vehicule;

import org.junit.jupiter.api.Test;

public class VehiculesTest {
    @Test
    void has_Proper_Modele_True() {
        // Given
        Vehicule legalVehicule = new Vehicule(1, "Renautlt", "clio", 4);
        // Then
        assertTrue(legalVehicule.hasProperModele());
    }
    @Test
    void has_Proper_Modele_False() {
        // Given
        Vehicule legalVehicule = new Vehicule(1, "Renautlt", null, 4);
        // Then
        assertFalse(legalVehicule.hasProperModele());
    }
    @Test
    void has_Proper_Constructeur_True() {
        // Given
        Vehicule legalVehicule = new Vehicule(1, "Renautlt", "clio", 4);
        // Then
        assertTrue(legalVehicule.hasProperConstructeur());
    }
    @Test
    void has_Proper_Constructeur_False() {
        // Given
        Vehicule legalVehicule = new Vehicule(1, null, "clio", 4);
        // Then
        assertFalse(legalVehicule.hasProperConstructeur());
    }
    @Test
    void has_Proper_NbPlaces_True() {
        // Given
        Vehicule legalVehicule = new Vehicule(1, "Renautlt", "clio", 4);
        // Then
        assertTrue(legalVehicule.hasProperNbPlaces());
    }
    @Test
    void has_Proper_NbPlaces_False() {
        // Given
        Vehicule legalVehicule = new Vehicule(1, "Renautlt", "clio", 1);
        // Then
        assertFalse(legalVehicule.hasProperNbPlaces());
    }

}
